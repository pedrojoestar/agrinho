let ingredients = [];
let pantry = ["tomate", "cenoura", "pão", "queijo", "alface", "ovo", "presunto", "pepino"];
let currentOrder = null;
let dishReady = false;
let dish = "";
let score = 0;

let maxOrderTime = 10000;
let orderStartTime = 0;

let lastClickedIngredient = "";

let resetIngredientsButton;

let confettiParticles = [];
const scoreToStartParty = 15;

function setup() {
  createCanvas(800, 450);
  generateOrder();

  resetIngredientsButton = createButton('Limpar Ingredientes');
  resetIngredientsButton.position(650, 15);
  resetIngredientsButton.mousePressed(resetIngredients);
  resetIngredientsButton.style('font-size', '14px');
  resetIngredientsButton.style('padding', '6px 12px');
  resetIngredientsButton.style('background-color', '#ff6b6b');
  resetIngredientsButton.style('color', '#fff');
  resetIngredientsButton.style('border', 'none');
  resetIngredientsButton.style('border-radius', '6px');
  resetIngredientsButton.style('cursor', 'pointer');

  confettiParticles = [];
  textFont('Segoe UI, Tahoma, Geneva, Verdana, sans-serif');
}

function draw() {
  background('#f7f7f7');
  image(img1,0,80)
  image(img2,-210,-15)

  drawHeader();
  drawKitchen();
  drawIngredients();
  drawOrder();
  drawDish();
  drawParty();
  drawScore();
  drawLastIngredient();

  if (!dishReady && millis() - orderStartTime > maxOrderTime) {
    ingredients = [];
    generateOrder();
  }
}
function preload(){
  img1 =loadImage("pixil-frame-0 (2).png")
  img2 =loadImage("pixil-frame-0 (1).png")
}

function drawHeader() {
  fill('#333');
  textSize(20);
  textAlign(LEFT, CENTER);
  text("🍳 Jogo da Cozinha - Prepare os pedidos rápido!", 20, 30);
}

function drawScore() {
  fill('#333');
  textSize(16);
  textAlign(LEFT, CENTER);
  text("Entregas feitas: " + score, 20, height - 20);
}

function drawKitchen() {
  fill('#c1c1c1');
  noStroke();
  rect(0, 350, width, 100);

  stroke('#999');
  strokeWeight(2);
  line(0, 350, width, 350);
}

function drawIngredients() {
  noStroke();
  for (let i = 0; i < pantry.length; i++) {
    fill('#90caf9');
    rect(50 + i * 90, 80, 70, 70, 10);

    fill('#1a237e');
    textSize(16);
    textAlign(CENTER, CENTER);
    text(pantry[i], 85 + i * 90, 115);
  }

  fill('#3949ab');
  textSize(18);
  textAlign(LEFT, CENTER);
  text("Ingredientes:", 50, 50);
}

// Caixa de Pedido
function drawOrder() {
  push();
  stroke('#3949ab');
  strokeWeight(2);
  fill('#e3f2fd');
  rect(530, 180, 240, 140, 12);
  pop();

  fill('#1a237e');
  textSize(18);
  textAlign(CENTER, TOP);
  text("Pedido", 650, 190);

  if (currentOrder) {
    textSize(16);
    textAlign(CENTER, TOP);
    text(currentOrder.name, 650, 220);
    textSize(15);
    text("Ingredientes:", 650, 245);
    text(currentOrder.ingredients.join(", "), 650, 265);

    let timeLeft = max(0, maxOrderTime - (millis() - orderStartTime));
    fill('#d32f2f');
    textSize(13);
    text("Tempo restante: " + (timeLeft / 1000).toFixed(1) + "s", 690, 295);
  }
}

function drawDish() {
  if (dishReady) {
    push();
    fill('#4caf50');
    stroke('#2e7d32');
    strokeWeight(3);
    rect(350, 320, 120, 60, 12);

    fill('#fff');
    noStroke();
    textAlign(CENTER, CENTER);
    textSize(18);
    text(dish, 410, 350);
    textSize(14);
    text("Servir", 410, 370);
    pop();
  }
}

function drawParty() {
  if (score >= scoreToStartParty) {
    if (confettiParticles.length === 0) {
      for (let i = 0; i < 60; i++) {
        confettiParticles.push(new Confetti(random(width / 2 - 100, width / 2 + 100), random(180, 260)));
      }
    }

    for (let p of confettiParticles) {
      p.update();
      p.display();
    }

    push();
    textSize(36);
    fill('#ffd600');
    stroke('#b28900');
    strokeWeight(4);
    textAlign(CENTER, CENTER);
    text("🎉 Festa na cidade! 🎉", width / 2, 260);
    pop();
  }
}

class Confetti {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(5, 10);
    this.speedY = random(0.5, 2);
    this.speedX = random(-0.5, 0.5);
    this.color = color(random(255), random(255), random(255), 200);
    this.angle = random(TWO_PI);
    this.angularSpeed = random(-0.05, 0.05);
    this.minX = width / 2 - 100;
    this.maxX = width / 2 + 100;
  }

  update() {
    this.y += this.speedY;
    this.x += this.speedX;
    this.angle += this.angularSpeed;

    if (this.x < this.minX) this.x = this.minX;
    if (this.x > this.maxX) this.x = this.maxX;

    if (this.y > 300) {
      this.y = random(180, 200);
      this.x = random(this.minX, this.maxX);
    }
  }

  display() {
    push();
    translate(this.x, this.y);
    rotate(this.angle);
    noStroke();
    fill(this.color);
    rect(0, 0, this.size, this.size / 3);
    pop();
  }
}

function drawLastIngredient() {
  if (lastClickedIngredient !== "") {
    let boxWidth = 220;
    let boxHeight = 30;
    let boxX = width / 2 - boxWidth / 2;
    let boxY = 40;

    fill('rgba(63, 81, 181, 0.15)');
    noStroke();
    rect(boxX, boxY, boxWidth, boxHeight, 8);

    fill('#3949ab');
    textSize(16);
    textAlign(CENTER, CENTER);
    text("Último ingrediente: " + lastClickedIngredient, width / 2, boxY + boxHeight / 2);
  }
}

function mousePressed() {
  for (let i = 0; i < pantry.length; i++) {
    if (mouseX > 50 + i * 90 && mouseX < 120 + i * 90 && mouseY > 80 && mouseY < 150) {
      ingredients.push(pantry[i]);
      lastClickedIngredient = pantry[i];
    }
  }

  if (dishReady && mouseX > 350 && mouseX < 470 && mouseY > 320 && mouseY < 380) {
    serveDish();
  }

  checkRecipe();
}

function generateOrder() {
  let recipes = [
    { name: "Salada", ingredients: ["tomate", "cenoura", "alface"] },
    { name: "Sanduíche", ingredients: ["pão", "tomate", "presunto", "queijo"] },
    { name: "Sopa", ingredients: ["cenoura", "pão", "ovo"] },
    { name: "Queijo quente", ingredients: ["queijo", "pão"] },
    { name: "Ovo mexido", ingredients: ["ovo", "queijo"] },
    { name: "Salada fresca", ingredients: ["alface", "tomate", "pepino"] },
    { name: "Sanduíche especial", ingredients: ["pão", "presunto", "queijo", "alface", "tomate"] }
  ];
  currentOrder = random(recipes);
  dishReady = false;
  dish = "";
  ingredients = [];
  orderStartTime = millis();
}

function checkRecipe() {
  if (arraysEqual(ingredients.slice().sort(), currentOrder.ingredients.slice().sort())) {
    dishReady = true;
    dish = currentOrder.name;
    ingredients = [];
  }
}

function serveDish() {
  score++;
  dishReady = false;
  dish = "";
  generateOrder();
}

function resetIngredients() {
  ingredients = [];
}

function arraysEqual(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}
